package com.example.ssn.controller;

import com.example.ssn.requests.MobileNumberValidatorRequest;
import com.example.ssn.responses.MobileNumberValidatorResponse;
import com.example.ssn.services.MobileNumberService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/validateMobileNumber")
public class MobileNumberController {
    private MobileNumberService mobileNumberService;

    public MobileNumberController(MobileNumberService mobileNumberService) {
        this.mobileNumberService = mobileNumberService;
    }

    @PostMapping
    public ResponseEntity<?> validateSSN(@RequestBody MobileNumberValidatorRequest mobileNumberValidatorRequest) {
        mobileNumberService.populateDemoMobileNumbers();
        MobileNumberValidatorResponse mobileNumberValidatorResponse = new MobileNumberValidatorResponse();
        mobileNumberValidatorResponse.setStatusCode(HttpStatus.OK);
        if (mobileNumberService.isMobileNumberValid(mobileNumberValidatorRequest.getMobileNumber())) {
            mobileNumberValidatorResponse.setMobileNumberValid(true);
        } else {
            mobileNumberValidatorResponse.setMobileNumberValid(false);
        }
        return ResponseEntity.status(HttpStatus.OK).body(mobileNumberValidatorResponse);
    }
}
