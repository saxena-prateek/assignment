package com.example.ssn.controller;

import com.example.ssn.requests.SSNValidatorRequest;
import com.example.ssn.responses.SSNValidatorResponse;
import com.example.ssn.services.SSNService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/validateSSN")
public class SSNController {
    private SSNService ssnService;

    public SSNController(SSNService ssnService) {
        this.ssnService = ssnService;
    }

    @PostMapping
    public ResponseEntity<?> validateSSN(@RequestBody SSNValidatorRequest ssnValidatorRequest) {
        ssnService.populateDemoSSNIds();
        SSNValidatorResponse ssnValidatorResponse = new SSNValidatorResponse();
        ssnValidatorResponse.setStatusCode(HttpStatus.OK);
        if (ssnService.isSSNValid(ssnValidatorRequest.getSsn())) {
            ssnValidatorResponse.setSsnValid(true);
        } else {
            ssnValidatorResponse.setSsnValid(false);
        }
        return ResponseEntity.status(HttpStatus.OK).body(ssnValidatorResponse);
    }
}
