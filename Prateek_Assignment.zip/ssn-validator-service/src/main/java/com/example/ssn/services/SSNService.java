package com.example.ssn.services;

import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class SSNService {
    private HashMap<String, Boolean> validSSNMap = new HashMap<>();

    public SSNService() {
    }

    public void populateDemoSSNIds() {
        validSSNMap.put("123456789", true);
        validSSNMap.put("678945123", true);
    }

    public Boolean isSSNValid(String ssn) {
        return validSSNMap.containsKey(ssn);
    }
}
