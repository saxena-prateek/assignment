package com.example.ssn.responses;

import org.springframework.http.HttpStatus;

public class SSNValidatorResponse {
    private HttpStatus statusCode;
    private Boolean ssnValid;

    public HttpStatus getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(HttpStatus statusCode) {
        this.statusCode = statusCode;
    }

    public Boolean getSsnValid() {
        return ssnValid;
    }

    public void setSsnValid(Boolean ssnValid) {
        this.ssnValid = ssnValid;
    }
}
