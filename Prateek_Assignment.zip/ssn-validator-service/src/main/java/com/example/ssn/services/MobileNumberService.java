package com.example.ssn.services;

import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class MobileNumberService {
    private HashMap<String, Boolean> validMobileNumberMap = new HashMap<>();

    public MobileNumberService() {
    }

    public void populateDemoMobileNumbers() {
        validMobileNumberMap.put("1234567890", true);
        validMobileNumberMap.put("9876543210", true);
    }

    public Boolean isMobileNumberValid(String mobileNumber) {
        return validMobileNumberMap.containsKey(mobileNumber);
    }
}
