package com.example.ssn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsnValidatorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
