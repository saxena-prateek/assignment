package com.example.ups.controllers;

import com.example.ups.entities.Customer;
import com.example.ups.services.CustomerService;
import com.example.ups.thirdparty.request.MobileNumberValidatorRequest;
import com.example.ups.thirdparty.request.SSNValidatorRequest;
import com.example.ups.thirdparty.response.CustomerValidatorResponse;
import com.example.ups.thirdparty.response.MobileNumberValidatorResponse;
import com.example.ups.thirdparty.response.SSNValidatorResponse;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/v1/validateCustomer")
public class CustomerController {
    private final CustomerService customerService;
    private final SSNValidatorController ssnValidatorController;
    private final MobileNumberValidatorController mobileNumberValidatorController;
    private Customer mainCustomer;
    private CustomerValidatorResponse customerValidatorResponse = new CustomerValidatorResponse();

    public CustomerController(CustomerService customerService,
                              SSNValidatorController ssnValidatorController,
                              MobileNumberValidatorController mobileNumberValidatorController) {
        this.customerService = customerService;
        this.ssnValidatorController = ssnValidatorController;
        this.mobileNumberValidatorController = mobileNumberValidatorController;
    }

    @PostMapping
    public ResponseEntity<?> validateCustomer(@Valid @RequestBody Customer customer, BindingResult bindingResult) {
        mainCustomer = customer;
        if (bindingResult.hasErrors()) {
            List<String> errors = bindingResult.getFieldErrors()
                    .stream()
                    .map(DefaultMessageSourceResolvable::getDefaultMessage)
                    .collect(Collectors.toList());
            return ResponseEntity.badRequest().body(errors);
        }

        Customer existingCustomer = customerService.getCustomerBySSN(customer.getSsn());
        //customerValidatorResponse = new CustomerValidatorResponse(); Moving to top level in POC to have ease for
        //combined scenario.
        if (existingCustomer != null && existingCustomer.getValidated()) {
            customerValidatorResponse.setStatusCode(HttpStatus.OK);
            customerValidatorResponse.setValidCustomer(true);
            return ResponseEntity.status(HttpStatus.OK).body(customerValidatorResponse);
        }
        /*CompletableFuture<String> combinedResult = handleCombinedResult();
        if (mainCustomer.getValidated() != null) {
            Customer createdUser = customerService.createCustomer(mainCustomer);
        }*/
        //Comment the below 2 lines and if block if we are using the combined scenario.
        handleSSNValidation(customer, customerValidatorResponse);
        handleMobileNumberValidation(customer, customerValidatorResponse);
        if (customer.getValidated() != null) {
            Customer createdUser = customerService.createCustomer(customer);
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(customerValidatorResponse);
    }

    /*
    The below two functions indicate how we can wait for the external APIs to finish their work and then use the result.
    This approach would ideally result in a blocking execution only. For parallel approach we should try the combined
    functions which are commented below.
     */

    private void handleMobileNumberValidation(Customer customer, CustomerValidatorResponse customerValidatorResponse) {
        MobileNumberValidatorRequest mobileNumberValidatorRequest = new MobileNumberValidatorRequest();
        mobileNumberValidatorRequest.setMobileNumber(customer.getMobileNumber());
        CompletableFuture<MobileNumberValidatorResponse> responseFuture =
                mobileNumberValidatorController.calMobileNumberValidatorService(mobileNumberValidatorRequest);
        if (responseFuture.isDone()) {
            responseFuture.thenAccept(responseEntity -> {
                HttpStatus statusCode = responseEntity.getStatusCode();
                Boolean isMobileNumberValid = responseEntity.getMobileNumberValid();
                if (isMobileNumberValid) {
                    if (customer.getValidated() != null && customer.getValidated()) {
                        customerValidatorResponse.setStatusCode(statusCode);
                        customerValidatorResponse.setValidCustomer(true);
                    }
                    if (customer.getValidated() == null) {
                        customerValidatorResponse.setStatusCode(statusCode);
                        customerValidatorResponse.setValidCustomer(false);
                    }
                } else {
                    customer.setValidated(null);
                    customerValidatorResponse.setStatusCode(statusCode);
                    customerValidatorResponse.setValidCustomer(false);
                }
            }).exceptionally(ex -> {
                ex.printStackTrace();
                customer.setValidated(null);
                customerValidatorResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                customerValidatorResponse.setValidCustomer(false);
                return null;
            });
        }
    }

    private void handleSSNValidation(Customer customer, CustomerValidatorResponse customerValidatorResponse) {
        SSNValidatorRequest ssnValidatorRequest = new SSNValidatorRequest();
        ssnValidatorRequest.setSsn(customer.getSsn().replaceAll("-", ""));
        ssnValidatorRequest.setDateOfBirth(customer.getDateOfBirth());
        CompletableFuture<SSNValidatorResponse> responseFuture =
                ssnValidatorController.calSSNValidatorService(ssnValidatorRequest);
        if (responseFuture.isDone()) {
            responseFuture.thenAccept(responseEntity -> {
                HttpStatus statusCode = responseEntity.getStatusCode();
                Boolean isSSNValid = responseEntity.getSsnValid();
                if (isSSNValid) {
                    customer.setValidated(true);
                    customerValidatorResponse.setStatusCode(statusCode);
                    customerValidatorResponse.setValidCustomer(true);
                } else {
                    customer.setValidated(null);
                    customerValidatorResponse.setStatusCode(statusCode);
                    customerValidatorResponse.setValidCustomer(false);
                }
            }).exceptionally(ex -> {
                ex.printStackTrace();
                customer.setValidated(null);
                customerValidatorResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                customerValidatorResponse.setValidCustomer(false);
                return null;
            });
        }
    }

    /**
     * The below approach is a way to demonstrate how we can use CompletableFuture Interface to trigger
     * the independent APIs in parallel and then wait for the combine result for customer validation service
     * to reply back as one unit.
     */

    private CompletableFuture<String> handleCombinedResult() {
        CompletableFuture<SSNValidatorResponse> future1 = CompletableFuture.supplyAsync(() -> {
            try {
                return getSSNValidResult();
            } catch (ExecutionException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });
        CompletableFuture<MobileNumberValidatorResponse> future2 = CompletableFuture.supplyAsync(() -> {
            try {
                return getMobileNumberValidResult();
            } catch (ExecutionException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });
        return CompletableFuture.allOf(future1, future2)
                .thenApply(ignored -> combineResults(future1.join(), future2.join()));
    }

    private String combineResults(SSNValidatorResponse ssnValidatorResponse,
                                  MobileNumberValidatorResponse mobileNumberValidatorResponse) {
        if (ssnValidatorResponse.getSsnValid()) {
            mainCustomer.setValidated(true);
            customerValidatorResponse.setStatusCode(ssnValidatorResponse.getStatusCode());
            customerValidatorResponse.setValidCustomer(true);
        } else {
            mainCustomer.setValidated(null);
            customerValidatorResponse.setStatusCode(ssnValidatorResponse.getStatusCode());
            customerValidatorResponse.setValidCustomer(false);
        }
        if (mobileNumberValidatorResponse.getMobileNumberValid()) {
            if (mainCustomer.getValidated() != null && mainCustomer.getValidated()) {
                customerValidatorResponse.setStatusCode(mobileNumberValidatorResponse.getStatusCode());
                customerValidatorResponse.setValidCustomer(true);
            }
            if (mainCustomer.getValidated() == null) {
                customerValidatorResponse.setStatusCode(mobileNumberValidatorResponse.getStatusCode());
                customerValidatorResponse.setValidCustomer(false);
            }
        } else {
            mainCustomer.setValidated(null);
            customerValidatorResponse.setStatusCode(mobileNumberValidatorResponse.getStatusCode());
            customerValidatorResponse.setValidCustomer(false);
        }
        return null;
    }

    private MobileNumberValidatorResponse getMobileNumberValidResult() throws ExecutionException, InterruptedException {
        MobileNumberValidatorRequest mobileNumberValidatorRequest = new MobileNumberValidatorRequest();
        mobileNumberValidatorRequest.setMobileNumber(mainCustomer.getMobileNumber());
        CompletableFuture<MobileNumberValidatorResponse> responseFuture =
                mobileNumberValidatorController.calMobileNumberValidatorService(mobileNumberValidatorRequest);
        return responseFuture.get();
    }

    private SSNValidatorResponse getSSNValidResult() throws ExecutionException, InterruptedException {
        SSNValidatorRequest ssnValidatorRequest = new SSNValidatorRequest();
        ssnValidatorRequest.setSsn(mainCustomer.getSsn().replaceAll("-", ""));
        ssnValidatorRequest.setDateOfBirth(mainCustomer.getDateOfBirth());
        CompletableFuture<SSNValidatorResponse> responseFuture =
                ssnValidatorController.calSSNValidatorService(ssnValidatorRequest);
        return responseFuture.get();
    }
}
