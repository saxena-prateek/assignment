package com.example.ups.constants;

public class CustomerValidationConstants {
    public static final String EMPTY_FIRST_NAME = "First Name is mandatory field.";
    public static final String EMPTY_LAST_NAME = "Last Name is mandatory field.";
    public static final String EMPTY_EMAIL = "Email is mandatory field.";
    public static final String INVALID_EMAIL_FORMAT = "Email format is invalid.";
    public static final String EMPTY_DATE_OF_BIRTH = "Date of birth is mandatory field.";
    public static final String INVALID_DATE_OF_BIRTH = "Date of birth must be in the yyyy-mm-dd format.";
    public static final String INVALID_SSN_FORMAT = "Invalid SSN number format.";
    public static final String EMPTY_SSN = "SSN is mandatory.";
    public static final String EMPTY_MOBILE_NUMBER = "Mobile number is mandatory.";
    public static final String INVALID_NUMBER_OF_DIGITS_IN_MOBILE_NUMBER = "A mobile number should have 10 digits.";
    public static final String INVALID_MOBILE_NUMBER = "Invalid mobile number.";

}
