package com.example.ups.controllers;

import com.example.ups.services.MobileNumberValidatorHelperService;
import com.example.ups.thirdparty.request.MobileNumberValidatorRequest;
import com.example.ups.thirdparty.response.MobileNumberValidatorResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.CompletableFuture;

@RestController
public class MobileNumberValidatorController {
    private MobileNumberValidatorHelperService mobileNumberValidatorHelperService;

    public MobileNumberValidatorController(MobileNumberValidatorHelperService mobileNumberValidatorHelperService) {
        this.mobileNumberValidatorHelperService = mobileNumberValidatorHelperService;
    }

    @PostMapping("/v1/validateMobileNumber")
    public CompletableFuture<MobileNumberValidatorResponse> calMobileNumberValidatorService(
            @RequestBody MobileNumberValidatorRequest requestBody) {
        return mobileNumberValidatorHelperService.callMobileNumberValidatorServiceAsync(requestBody);
    }
}
