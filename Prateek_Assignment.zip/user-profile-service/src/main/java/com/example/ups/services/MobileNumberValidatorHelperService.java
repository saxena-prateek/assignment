package com.example.ups.services;

import com.example.ups.thirdparty.request.MobileNumberValidatorRequest;
import com.example.ups.thirdparty.response.MobileNumberValidatorResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletableFuture;
@Service
public class MobileNumberValidatorHelperService {
    private final WebClient webClient;

    public MobileNumberValidatorHelperService(WebClient.Builder webClientBuilder,
                                              @Value("${spring.mobile.number.validator.service.url}") String mobileValidatorServiceUrl) {
        this.webClient = webClientBuilder.baseUrl(mobileValidatorServiceUrl).build();
    }

    /*
    As the Rest Template is deprecated, Using the WebClient from the reactive package and using the CompletableFuture
    to achieve the same behavior as defining an executor pool and calling external APIs with Future interface.
     */
    public CompletableFuture<MobileNumberValidatorResponse> callMobileNumberValidatorServiceAsync(MobileNumberValidatorRequest requestBody) {
        return Mono.fromCallable(() -> webClient.post()
                        .body(BodyInserters.fromValue(requestBody))
                        .retrieve()
                        .bodyToMono(MobileNumberValidatorResponse.class)
                        .block())
                .toFuture();
    }
}
