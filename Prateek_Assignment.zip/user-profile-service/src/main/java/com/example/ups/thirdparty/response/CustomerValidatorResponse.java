package com.example.ups.thirdparty.response;

import org.springframework.http.HttpStatus;

public class CustomerValidatorResponse {
    private HttpStatus statusCode;
    private Boolean validCustomer;

    public HttpStatus getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(HttpStatus statusCode) {
        this.statusCode = statusCode;
    }

    public Boolean getValidCustomer() {
        return validCustomer;
    }

    public void setValidCustomer(Boolean validCustomer) {
        this.validCustomer = validCustomer;
    }
}
