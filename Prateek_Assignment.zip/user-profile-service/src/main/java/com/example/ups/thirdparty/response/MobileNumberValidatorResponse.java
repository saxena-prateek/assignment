package com.example.ups.thirdparty.response;

import org.springframework.http.HttpStatus;

public class MobileNumberValidatorResponse {
    private HttpStatus statusCode;
    private Boolean mobileNumberValid;

    public HttpStatus getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(HttpStatus statusCode) {
        this.statusCode = statusCode;
    }

    public Boolean getMobileNumberValid() {
        return mobileNumberValid;
    }

    public void setMobileNumberValid(Boolean mobileNumberValid) {
        this.mobileNumberValid = mobileNumberValid;
    }
}
