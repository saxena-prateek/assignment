package com.example.ups.entities;


import com.example.ups.constants.CustomerValidationConstants;

import javax.persistence.*;
import javax.validation.constraints.*;

@Entity
@Table(name = "customer")
public class Customer {

    @NotBlank(message = CustomerValidationConstants.EMPTY_FIRST_NAME)
    private String firstName;

    @NotBlank(message = CustomerValidationConstants.EMPTY_LAST_NAME)
    private String lastName;

    @NotBlank(message = CustomerValidationConstants.EMPTY_EMAIL)
    @Email(message = CustomerValidationConstants.INVALID_EMAIL_FORMAT)
    private String email;

    @NotBlank(message = CustomerValidationConstants.EMPTY_DATE_OF_BIRTH)
    @Pattern(regexp = "^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$",
            message = CustomerValidationConstants.INVALID_DATE_OF_BIRTH)
    private String dateOfBirth;

    /*
        United States Social Security numbers are nine-digit numbers in the format AAA-GG-SSSS with following rules.
        The first three digits called the area number. The area number cannot be 000, 666, or between 900 and 999.
        Digits four and five are called the group number and range from 01 to 99.
        The last four digits are serial numbers from 0001 to 9999.
     */
    @Id
    @Pattern(regexp = "^(?!000|666)[0-8][0-9]{2}-(?!00)[0-9]{2}-(?!0000)[0-9]{4}$",
            message = CustomerValidationConstants.INVALID_SSN_FORMAT)
    @NotBlank(message = CustomerValidationConstants.EMPTY_SSN)
    private String ssn;

    @NotBlank(message = CustomerValidationConstants.EMPTY_MOBILE_NUMBER)
    @Size(min = 10, max = 10, message = CustomerValidationConstants.INVALID_NUMBER_OF_DIGITS_IN_MOBILE_NUMBER)
    @Pattern(regexp = "^\\d{10}$", message = CustomerValidationConstants.INVALID_MOBILE_NUMBER)
    private String mobileNumber;

    private Boolean isValidated;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public Boolean getValidated() {
        return isValidated;
    }

    public void setValidated(Boolean validated) {
        isValidated = validated;
    }
}
