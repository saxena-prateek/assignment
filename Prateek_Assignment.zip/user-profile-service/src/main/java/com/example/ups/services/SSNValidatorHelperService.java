package com.example.ups.services;

import com.example.ups.thirdparty.request.SSNValidatorRequest;
import com.example.ups.thirdparty.response.SSNValidatorResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.concurrent.CompletableFuture;

@Service
public class SSNValidatorHelperService {
    private final WebClient webClient;

    public SSNValidatorHelperService(WebClient.Builder webClientBuilder,
                                     @Value("${spring.ssn.validator.service.url}") String ssnValidatorServiceUrl) {
        this.webClient = webClientBuilder.baseUrl(ssnValidatorServiceUrl).build();
    }

    /*
    As the Rest Template is deprecated, Using the WebClient from the reactive package and using the CompletableFuture
    to achieve the same behavior as defining an executor pool and calling external APIs with Future interface.
     */
    public CompletableFuture<SSNValidatorResponse> callSSNValidatorServiceAsync(SSNValidatorRequest requestBody) {
        return Mono.fromCallable(() -> webClient.post()
                        .body(BodyInserters.fromValue(requestBody))
                        .retrieve()
                        .bodyToMono(SSNValidatorResponse.class)
                        .block())
                .toFuture();
    }
}
