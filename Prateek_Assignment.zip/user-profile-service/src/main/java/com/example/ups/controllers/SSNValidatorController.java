package com.example.ups.controllers;

import com.example.ups.services.SSNValidatorHelperService;
import com.example.ups.thirdparty.request.SSNValidatorRequest;
import com.example.ups.thirdparty.response.SSNValidatorResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.CompletableFuture;

@RestController
public class SSNValidatorController {
    private SSNValidatorHelperService ssnValidatorHelperService;

    public SSNValidatorController(SSNValidatorHelperService ssnValidatorHelperService) {
        this.ssnValidatorHelperService = ssnValidatorHelperService;
    }

    @PostMapping("/v1/validateSSN")
    public CompletableFuture<SSNValidatorResponse> calSSNValidatorService(@RequestBody SSNValidatorRequest requestBody) {
        return ssnValidatorHelperService.callSSNValidatorServiceAsync(requestBody);
    }
}
