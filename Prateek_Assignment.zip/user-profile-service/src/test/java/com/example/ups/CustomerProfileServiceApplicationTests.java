package com.example.ups;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProfileServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
