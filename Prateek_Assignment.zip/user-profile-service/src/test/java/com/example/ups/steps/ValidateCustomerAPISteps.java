package com.example.ups.steps;

import com.example.ups.entities.Customer;
import com.example.ups.services.CustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@CucumberContextConfiguration
@SpringBootTest
@AutoConfigureMockMvc
public class ValidateCustomerAPISteps {
    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private MvcResult mvcResult;

    @Given("the user profile service is running")
    public void theApiIsRunning() {
    }

    @When("User sends a POST request to {string} with blank json body:")
    public void userSendsPostRequestWithBlankJsonBody(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @Then("the response status code should be {int}")
    public void theResponseStatusCodeShouldBe(int statusCode) {
        assertEquals(statusCode, mvcResult.getResponse().getStatus());
    }

    @And("the response should contain the message {string}")
    public void theResponseBodyShouldContainMessage(String expectedMessage) throws Exception {
        String responseBody = mvcResult.getResponse().getContentAsString();
        assertTrue(responseBody.contains(expectedMessage));
    }

    @When("User sends a POST request to {string} with empty first name in json body:")
    public void userSendsPostRequestWithEmptyFirstName(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with empty last name in json body:")
    public void userSendsPostRequestWithEmptyLastName(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with empty email in json body:")
    public void userSendsPostRequestWithEmptyEmail(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with invalid email in json body:")
    public void userSendsPostRequestWithInvalidEmail(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with empty dob in json body:")
    public void userSendsPostRequestWithEmptyDOB(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with invalid dob in json body:")
    public void userSendsPostRequestWithInvalidDOB(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with empty ssn in json body:")
    public void userSendsPostRequestWithEmptySSN(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with invalid ssn in json body:")
    public void userSendsPostRequestWithInvalidSSN(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with empty mobile number in json body:")
    public void userSendsPostRequestWithEmptyMobileNumber(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with invalid number of digits in mobile number in json body:")
    public void userSendsPostRequestWithInvalidNumberOfDigitsInMobileNumber(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with invalid mobile number in json body:")
    public void userSendsPostRequestWithInvalidMobileNumber(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    @When("User sends a POST request to {string} with all proper parameters in json body:")
    public void userSendsPostRequestWithAllValidParameters(String url, String jsonBody) throws Exception {
        mvcResult = createPostRequest(url, jsonBody, MediaType.APPLICATION_JSON);
    }

    private MvcResult createPostRequest(String url, String jsonBody, MediaType mediaType) throws Exception {
        Customer customer = objectMapper.readValue(jsonBody, Customer.class);
        return mockMvc.perform(MockMvcRequestBuilders.post(url)
                        .content(objectMapper.writeValueAsString(customer))
                        .contentType(mediaType))
                .andReturn();
    }
}
